# Expanded V2 Atlas

- Scope: 150 Chapters
- Candidates Researched: 36
- Approved: 31