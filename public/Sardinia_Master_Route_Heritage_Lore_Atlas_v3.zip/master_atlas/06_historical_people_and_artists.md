# Verified List
- Grazia Deledda
- Maria Lai
- Giovanni Lilliu